# IN REL 002 Certificate Checker — Vercel deployment

## Deploy
1. Create a MongoDB Atlas cluster and database user. Add the Vercel deployment's outbound access to Atlas Network Access. For a quick trial Atlas allows `0.0.0.0/0`, but it is broader than ideal; use your organization's approved network/security approach for production.
2. In Atlas, copy the application's connection string. Replace the username/password placeholders and database name.
3. Upload this project to a GitHub repository (the simplest Vercel import path) or import the project into Vercel with the project root set to this folder.
4. In Vercel Project Settings → Environment Variables, add `MONGODB_URI` with the full Atlas URI. Set it for Production and Preview as needed. Do not put the URI in client code or commit it to Git.
5. Deploy. Vercel should use `npm run build`, output `client/dist`, and route `/api/*` to `api/[...path].js`.
6. Open `/api/health` on the deployed domain to check that the function is reachable. If the database isn't connected, check `MONGODB_URI`, Atlas database-user credentials, and Network Access.

## Environment variables
Only `MONGODB_URI` is required by this deployment. OCR uses Tesseract.js in the browser and doesn't require an API key. The first OCR run may need to download the English OCR language data from its configured CDN, so it isn't guaranteed to work in a fully offline browser.

## Important
- This app currently has no user login/role access control. Do not publish sensitive calibration records or rely on it as an unrestricted public production service. Restrict access through an approved protection layer before using real company data.
- OCR output must be manually verified. The app does not automatically infer official IN REL 002 limits. Configure each rule from the controlled procedure and verify it before operational use.
- Use a private repository if certificates contain company-confidential information. Never include real credentials in this ZIP or source control.
