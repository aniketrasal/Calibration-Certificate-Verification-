import express from 'express';
import mongoose from 'mongoose';

const app = express();
app.use(express.json({ limit: '8mb' }));

// Vercel may forward the original /api prefix to a catch-all function.
app.use((req, _res, next) => {
  if (req.url === '/api') req.url = '/';
  else if (req.url.startsWith('/api/')) req.url = req.url.slice(4);
  next();
});

const reviewSchema = new mongoose.Schema({
  title: { type: String, required: true }, instrumentName: String, instrumentId: String,
  make: String, modelSerial: String, range: String, resolution: String,
  certificateNo: String, ulrNo: String, labName: String, calibrationDate: String,
  dueDate: String, referenceStandard: String, procedure: String, uncertainty: String,
  permissibleError: Number, observedError: Number, ocrText: String, ocrFileName: String,
  notes: String, checks: [{ key: String, label: String, status: String, comment: String }],
  verdict: String, createdAt: { type: Date, default: Date.now }
}, { timestamps: true });
const ruleSchema = new mongoose.Schema({
  instrumentType: { type: String, required: true }, rangeMin: { type: Number, default: 0 },
  rangeMax: { type: Number, required: true }, maxError: { type: Number, required: true },
  unit: { type: String, default: 'µm' }, procedure: String, referenceStandard: String,
  sourcePage: String, active: { type: Boolean, default: true }, verifiedBy: String, verifiedDate: String
}, { timestamps: true });
const Review = mongoose.models.Review || mongoose.model('Review', reviewSchema);
const Rule = mongoose.models.Rule || mongoose.model('Rule', ruleSchema);

let connectionPromise;
async function connectDB() {
  if (mongoose.connection.readyState === 1) return;
  if (!process.env.MONGODB_URI) throw new Error('MONGODB_URI environment variable is missing.');
  if (!connectionPromise) {
    connectionPromise = mongoose.connect(process.env.MONGODB_URI, { serverSelectionTimeoutMS: 10000 })
      .catch(err => { connectionPromise = null; throw err; });
  }
  await connectionPromise;
}
app.use(async (_req, res, next) => {
  try { await connectDB(); next(); }
  catch (e) { res.status(503).json({ error: 'Database connection failed', details: e.message }); }
});
app.get('/health', (_req, res) => res.json({ ok: true, service: 'IN REL 002 Certificate Checker API', ocr: 'browser-local Tesseract.js' }));
app.get('/reviews', async (_req, res) => { try { res.json(await Review.find().sort({ createdAt: -1 }).limit(100)); } catch (e) { res.status(500).json({ error: 'Database read failed', details: e.message }); } });
app.get('/reviews/:id', async (req, res) => { try { const d = await Review.findById(req.params.id); if (!d) return res.status(404).json({ error: 'Not found' }); res.json(d); } catch { res.status(400).json({ error: 'Invalid review ID' }); } });
app.post('/reviews', async (req, res) => { try { const d = await Review.create(req.body); res.status(201).json(d); } catch (e) { res.status(400).json({ error: 'Could not save review', details: e.message }); } });
app.delete('/reviews/:id', async (req, res) => { try { await Review.findByIdAndDelete(req.params.id); res.json({ ok: true }); } catch { res.status(400).json({ error: 'Invalid review ID' }); } });
app.get('/rules', async (_req, res) => { try { res.json(await Rule.find().sort({ instrumentType: 1, rangeMax: 1 })); } catch (e) { res.status(500).json({ error: 'Could not load rules', details: e.message }); } });
app.post('/rules', async (req, res) => { try { const d = await Rule.create(req.body); res.status(201).json(d); } catch (e) { res.status(400).json({ error: 'Could not save rule', details: e.message }); } });
app.put('/rules/:id', async (req, res) => { try { const d = await Rule.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true }); if (!d) return res.status(404).json({ error: 'Rule not found' }); res.json(d); } catch (e) { res.status(400).json({ error: 'Could not update rule', details: e.message }); } });
app.delete('/rules/:id', async (req, res) => { try { await Rule.findByIdAndDelete(req.params.id); res.json({ ok: true }); } catch { res.status(400).json({ error: 'Invalid rule ID' }); } });
app.use((_req, res) => res.status(404).json({ error: 'API endpoint not found' }));

export default app;
