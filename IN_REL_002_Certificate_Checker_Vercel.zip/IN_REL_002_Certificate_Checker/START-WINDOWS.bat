@echo off
cd /d "%~dp0"
echo Installing root dependencies...
call npm install
if errorlevel 1 goto error
echo Installing app dependencies...
call npm run install:all
if errorlevel 1 goto error
echo Starting Certificate Checker...
call npm run dev
goto end
:error
echo.
echo Setup failed. Check that Node.js and MongoDB are installed and try again.
pause
:end
