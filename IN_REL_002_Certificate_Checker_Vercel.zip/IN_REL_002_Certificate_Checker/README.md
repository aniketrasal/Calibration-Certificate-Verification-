# IN REL 002 Calibration Certificate Checker

Local React/Vite + Express/MongoDB application with browser-side OCR for certificate images and PDFs.

## Features
- OCR for images and multi-page PDFs using Tesseract.js + PDF.js in the browser. The original certificate is not uploaded to the Express API; OCR text is saved only if you save the review.
- Best-effort auto-fill of instrument, ID, make, range, resolution, certificate number, ULR, laboratory, dates, reference standard, procedure and uncertainty.
- Review checklist, editable OCR text, CSV export and MongoDB review history.
- Rule configuration screen to enter approved instrument/range-specific permissible-error limits, units, procedure clause, source page and reviewer details.
- Verdicts remain REVIEW REQUIRED when no active configured rule matches. Observed error must be checked and entered by the reviewer because OCR may misread signs, decimals, units or result tables.

## Important rule status
The previously uploaded certificate photos were recovered and reviewed. They include calibration certificates for a digital caliper, digital height gauge, digital depth vernier caliper, digital lux meter, granite surface plate and weighing balance, plus a surface-plate accuracy table referencing IS 7327:2003. The accessible image set did not include a clearly readable controlled IN REL 002 procedure page. Therefore, no unverified limits are hard-coded or pre-approved. Add rule rows only after checking the current controlled IN REL 002 document. Do not use this draft as an automatic release/acceptance authority until Quality validates the rules and tests the parser against representative certificates.

## Requirements
- Node.js 20+ (tested target: Node 22)
- MongoDB Community Server running locally, or configure `MONGODB_URI` in `server/.env`
- Internet access may be needed the first time OCR model assets are fetched by Tesseract.js. Certificate files themselves are processed in the browser and are not sent to a cloud OCR API.

## Start on Windows
1. Install Node.js and MongoDB Community Server.
2. Start the MongoDB service.
3. Run `START-WINDOWS.bat`.
4. Open `http://localhost:5173`.
5. Upload a certificate image/PDF, wait for OCR, and manually verify every extracted field.
6. Open **IN REL 002 rules** and enter only the exact limits transcribed and approved from the controlled procedure. Record source page and reviewer.

First run installs npm dependencies, so internet access is required for installation. Do not use an unapproved external OCR/cloud service for confidential company certificates.
