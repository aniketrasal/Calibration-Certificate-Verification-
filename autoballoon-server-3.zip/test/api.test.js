'use strict';
const http = require('http'), fs = require('fs'), os = require('os'), path = require('path');
const fileStore = require('../lib/store_file'), createApp = require('../lib/app');
let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };

async function run(store, label, opts = {}) {
  console.log('--- ' + label);
  const handle = createApp({ store, secret: 'x'.repeat(40), allowSetup: !!opts.setup, seed: opts.seed });
  const srv = http.createServer(handle); await new Promise(r => srv.listen(0, '127.0.0.1', r)); const base = 'http://127.0.0.1:' + srv.address().port;
  const client = () => { let cookie = ''; return async (m, p, body, hdr = {}) => {
    const r = await fetch(base + p, { method: m, headers: Object.assign({ 'Content-Type': 'application/json', 'X-Requested-With': 'autoballoon', cookie }, hdr), body: body ? JSON.stringify(body) : undefined });
    const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0].endsWith('=') ? '' : sc.split(';')[0];
    let d = null; try { d = await r.json(); } catch (e) { } return { s: r.status, d, h: r.headers }; }; };
  const anon = client(), admin = client(), sup = client(), mgr = client(), sup2 = client();

  ok((await anon('GET', '/api/me')).s === 401, 'not signed in → 401');
  ok((await anon('POST', '/api/login', { username: 'a', password: 'b' }, { 'X-Requested-With': 'evil' })).s === 403, 'missing CSRF header → 403');
  if (opts.setup) {
    ok((await anon('GET', '/api/status')).d.needsSetup === true, 'first run needs setup');
    ok((await anon('POST', '/api/setup', { username: 'x y', password: 'longenough1' })).s === 400, 'setup rejects bad username');
    ok((await anon('POST', '/api/setup', { username: 'admin', name: 'Asha Admin', password: 'short' })).s === 400, 'setup rejects short password');
    const s = await admin('POST', '/api/setup', { username: 'Admin', name: 'Asha Admin', password: 'admin-pass-1' }); ok(s.s === 200 && s.d.user.role === 'admin', 'setup creates the first admin');
    ok((await anon('POST', '/api/setup', { username: 'evil', password: 'longenough1' })).s === 403, 'setup is closed once a user exists');
  } else {
    ok((await anon('GET', '/api/status')).d.needsSetup === false, 'web mode never offers open setup');
    const l = await admin('POST', '/api/login', { username: opts.seed.username, password: opts.seed.password }); ok(l.s === 200 && l.d.user.role === 'admin' && l.d.user.mustChange, 'seeded admin can sign in (must change password)');
    ok((await admin('POST', '/api/me/password', { current: opts.seed.password, next: 'admin-pass-1' })).s === 200, 'seeded admin changes password');
  }
  ok((await admin('GET', '/api/me')).d.user.username === 'admin', 'session cookie works');
  ok(!JSON.stringify((await admin('GET', '/api/users')).d).includes('scrypt'), 'user list never exposes password hashes');

  const mk = (n, role) => admin('POST', '/api/users', { username: n, name: n.toUpperCase(), role, password: 'temp-pass-' + n });
  ok((await mk('meena', 'manager')).s === 200, 'second manager'); ok((await mk('sunita', 'supervisor')).s === 200, 'admin creates supervisor'); ok((await mk('manoj', 'manager')).s === 200, 'admin creates manager'); ok((await mk('ravi', 'supervisor')).s === 200, 'admin creates 2nd supervisor');
  ok((await mk('sunita', 'manager')).s === 409, 'duplicate username → 409'); ok((await admin('POST', '/api/users', { username: 'zz9', role: 'boss', password: 'longenough1' })).s === 400, 'bad role rejected');
  ok((await sup('POST', '/api/login', { username: 'sunita', password: 'wrong' })).s === 401, 'wrong password → 401');
  const ls = await sup('POST', '/api/login', { username: 'SUNITA', password: 'temp-pass-sunita' }); ok(ls.s === 200 && ls.d.user.mustChange, 'supervisor signs in (case-insensitive), must change password');
  ok((await sup('POST', '/api/me/password', { current: 'nope', next: 'new-pass-sunita' })).s === 400, 'change password needs the current one');
  ok((await sup('POST', '/api/me/password', { current: 'temp-pass-sunita', next: 'new-pass-sunita' })).s === 200, 'supervisor changes password');
  await mgr('POST', '/api/login', { username: 'manoj', password: 'temp-pass-manoj' }); await sup2('POST', '/api/login', { username: 'ravi', password: 'temp-pass-ravi' });

  // role enforcement
  ok((await sup('GET', '/api/users')).s === 403, 'supervisor cannot list users'); ok((await mgr('POST', '/api/users', { username: 'hack', role: 'admin', password: 'longenough1' })).s === 403, 'manager cannot create users');
  const supId = (await sup('GET', '/api/me')).d.user.id, rid = supId + '_plan1';
  const mgrId = (await mgr('GET', '/api/me')).d.user.id;
  const snap = { approvers: [mgrId], planId: 'plan1', part: 'P-1', rev: 'A', type: 'Final', summary: { total: 2, ok: 2, nok: 0, pending: 0, overall: 'ACCEPT' }, report: { inspector: 'Sunita', samples: 3 }, rows: [{ no: 1, spec: 'Ø10±0.1', obs: ['10', '10.05', '9.95'], res: 'OK' }, { no: 2, spec: '5±0.1', obs: ['5', '5', '5'], res: 'OK' }] };
  ok((await sup2('PUT', '/api/reports/' + rid, snap)).s === 403, "cannot submit in someone else's name");
  const put = await sup('PUT', '/api/reports/' + rid, Object.assign({ status: 'approved', submitter: 'x' }, snap)); ok(put.s === 200 && put.d.report.status === 'pending' && put.d.report.submitter === supId, 'submit → pending (client cannot self-approve)');
  ok((await sup('POST', '/api/reports/' + rid + '/decision', { status: 'approved' })).s === 403, 'supervisor cannot approve');
  ok((await sup2('GET', '/api/reports')).d.reports.length === 0, 'other supervisor does not see it'); ok((await sup2('GET', '/api/reports/' + rid)).s === 404, 'other supervisor cannot open it');
  ok((await sup('GET', '/api/reports')).d.reports.length === 1 && !('rows' in (await sup('GET', '/api/reports')).d.reports[0]), 'own list is summaries only');
  // approver selection
  ok((await sup('PUT', '/api/reports/' + rid, Object.assign({}, snap, { approvers: [] }))).s === 400, 'must choose a manager');
  ok((await sup('PUT', '/api/reports/' + rid, Object.assign({}, snap, { approvers: [supId] }))).s === 400, 'only managers can be chosen');
  const ap = (await sup('GET', '/api/approvers')).d.approvers; ok(ap.length === 2 && ap.every(x => x.id && x.name), 'approver list = managers only');
  const mgr2 = client(); await mgr2('POST', '/api/login', { username: 'meena', password: 'temp-pass-meena' });
  ok((await mgr2('GET', '/api/reports')).d.reports.length === 0, 'unselected manager does not see the report'); ok((await mgr2('GET', '/api/reports/' + rid)).s === 404, 'unselected manager cannot open it');
  ok((await mgr2('POST', '/api/reports/' + rid + '/decision', { status: 'approved' })).s === 404, 'unselected manager cannot decide');
  ok((await admin('GET', '/api/reports')).d.reports.length === 1, 'admin sees every report');
  ok((await mgr('GET', '/api/reports')).d.reports.length === 1, 'selected manager sees it'); ok((await mgr('GET', '/api/reports')).d.reports[0].approvers[0] === mgrId, 'sent-to is recorded');
  ok((await mgr('GET', '/api/reports')).d.reports.length === 1, 'manager sees all'); ok((await mgr('GET', '/api/reports/' + rid)).d.report.rows.length === 2, 'manager opens full report');
  ok((await mgr('POST', '/api/reports/' + rid + '/decision', { status: 'maybe' })).s === 400, 'bad decision rejected');
  const dec = await mgr('POST', '/api/reports/' + rid + '/decision', { status: 'approved', note: 'ok' }); ok(dec.s === 200 && dec.d.report.status === 'approved' && dec.d.report.decision.name === 'MANOJ', 'manager approves');
  ok((await sup('PUT', '/api/reports/' + rid, snap)).d.report.status === 'pending', 're-submit resets approval');
  ok((await sup2('DELETE', '/api/reports/' + rid)).s === 403, "cannot withdraw someone else's"); ok((await sup('DELETE', '/api/reports/' + rid)).s === 200, 'supervisor withdraws own');

  // plans live on the server, per account
  const plan = { id: 'pl_abc1', partNo: 'P-77', balloons: [{ id: 'b1', no: 1, text: 'Ø10' }], pages: 1 };
  ok((await anon('GET', '/api/plans')).s === 401, 'plans need sign-in');
  ok((await sup('PUT', '/api/plans/pl_abc1', plan)).s === 200, 'supervisor saves a plan');
  const sup_b = client(); await sup_b('POST', '/api/login', { username: 'sunita', password: 'new-pass-sunita' });
  ok((await sup_b('GET', '/api/plans')).d.plans.length === 1, 'same account on another browser sees the plan'); ok((await sup_b('GET', '/api/plans/pl_abc1')).d.plan.balloons.length === 1, 'and its balloons');
  ok((await sup2('GET', '/api/plans')).d.plans.length === 0, 'other supervisor does not see it'); ok((await sup2('GET', '/api/plans/pl_abc1')).s === 404, 'other supervisor cannot open it'); ok((await sup2('PUT', '/api/plans/pl_abc1', plan)).s === 404, 'other supervisor cannot overwrite it'); ok((await sup2('DELETE', '/api/plans/pl_abc1')).s === 404 && (await sup('GET', '/api/plans/pl_abc1')).s === 200, "other supervisor's delete does nothing");
  ok((await admin('GET', '/api/plans')).d.plans.length === 1, 'admin sees all plans');
  const pdf = Buffer.alloc(5 * 1024 * 1024 + 123, 7), CH = 2 * 1024 * 1024, n = Math.ceil(pdf.length / CH);
  for (let i = 0; i < n; i++) ok((await sup('PUT', '/api/plans/pl_abc1/file', { i, n, data: pdf.subarray(i * CH, (i + 1) * CH).toString('base64') })).s === 200, 'upload chunk ' + (i + 1) + '/' + n);
  let got = []; for (let i = 0, nn = 1; i < nn; i++) { const r = await sup_b('GET', '/api/plans/pl_abc1/file?i=' + i); nn = r.d.n; got.push(Buffer.from(r.d.data, 'base64')); }
  ok(Buffer.concat(got).equals(pdf), 'drawing downloads intact on another browser (' + got.length + ' chunks)'); ok((await sup2('GET', '/api/plans/pl_abc1/file?i=0')).s === 404, 'other supervisor cannot download it');
  ok((await sup('PUT', '/api/cfg', { cfg: { methods: ['x'] } })).s === 200 && (await sup_b('GET', '/api/cfg')).d.cfg.methods[0] === 'x', 'settings follow the account');
  ok((await sup('DELETE', '/api/plans/pl_abc1')).s === 200 && (await sup('GET', '/api/plans')).d.plans.length === 0 && (await sup_b('GET', '/api/plans/pl_abc1/file?i=0')).s === 404, 'delete removes plan and drawing');
  // admin safety + session invalidation
  const adminId = (await admin('GET', '/api/me')).d.user.id, users = (await admin('GET', '/api/users')).d.users, sunita = users.find(u => u.username === 'sunita');
  ok((await admin('DELETE', '/api/users/' + adminId)).s === 400, 'admin cannot delete self'); ok((await admin('PATCH', '/api/users/' + adminId, { role: 'manager' })).s === 400, 'last admin cannot be demoted');
  ok((await admin('PATCH', '/api/users/' + sunita.id, { role: 'manager' })).d.user.role === 'manager', 'role change'); ok((await admin('PATCH', '/api/users/' + sunita.id, { password: 'reset-pass-1' })).s === 200, 'admin resets password');
  ok((await sup('GET', '/api/me')).s === 401, 'password reset signs the user out');
  ok((await sup('POST', '/api/login', { username: 'sunita', password: 'reset-pass-1' })).s === 200, 'new password works');
  await admin('PATCH', '/api/users/' + sunita.id, { disabled: true }); ok((await sup('GET', '/api/me')).s === 401, 'disabled user is signed out'); ok((await sup('POST', '/api/login', { username: 'sunita', password: 'reset-pass-1' })).s === 401, 'disabled user cannot sign in');
  await admin('DELETE', '/api/users/' + sunita.id); ok((await admin('GET', '/api/users')).d.users.every(u => u.username !== 'sunita'), 'admin deletes user');
  // lockout
  for (let i = 0; i < 8; i++) await anon('POST', '/api/login', { username: 'ravi', password: 'bad' + i });
  ok((await anon('POST', '/api/login', { username: 'ravi', password: 'temp-pass-ravi' })).s === 429, 'account locks after repeated failures');
  ok((await anon('POST', '/api/logout')).s === 200, 'logout ok');
  srv.close();
}
(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'abdata-')); const st = fileStore(dir);
  await run(st, 'LOCAL (file store, first-run setup)', { setup: true });
  ok(fs.existsSync(path.join(dir, 'db.json')) && !fs.readFileSync(path.join(dir, 'db.json'), 'utf8').includes('admin-pass-1'), 'db.json is on disk and holds no plain passwords');
  const st2 = fileStore(dir); ok((await st2.countUsers()) >= 2, 'data survives a restart');
  // WEB path with the MongoDB adapter, against an in-memory stand-in for the driver
  const mem = { users: new Map(), reports: new Map(), plans: new Map(), files: new Map(), cfg: new Map() };
  const coll = (n) => ({ createIndex: async () => { }, countDocuments: async (q) => [...mem[n].values()].filter(d => !q || Object.entries(q).every(([k, v]) => d[k] === v)).length, findOne: async (q) => { for (const d of mem[n].values()) if (Object.entries(q).every(([k, v]) => d[k] === v)) return JSON.parse(JSON.stringify(d)); return null; },
    find: () => ({ toArray: async () => [...mem[n].values()].map(d => JSON.parse(JSON.stringify(d))) }), replaceOne: async (q, d) => { mem[n].set(q._id, JSON.parse(JSON.stringify(d))); }, deleteOne: async (q) => { mem[n].delete(q._id); }, deleteMany: async (q) => { for (const [k, d] of [...mem[n]]) if (Object.entries(q).every(([a, v]) => d[a] === v)) mem[n].delete(k); } });
  require.cache[require.resolve('module')]; const Module = require('module'); const orig = Module._load;
  Module._load = function (req, ...a) { return req === 'mongodb' ? { MongoClient: class { async connect() { } db() { return { collection: coll }; } } } : orig.call(this, req, ...a); };
  const ms = require('../lib/store_mongo')({ uri: 'mongodb://fake' });
  await run(ms, 'WEB (MongoDB adapter, env-seeded admin)', { setup: false, seed: { username: 'admin', password: 'seed-pass-123', name: 'Asha Admin' } });
  console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
