# AutoBalloon – web + local editions

One app, two ways to run it. Both need a **username and password**, both have the same three roles:

| Role | Can do |
|---|---|
| **Quality Supervisor** | Add drawings, auto-balloon, plans, inspection reports, submit reports for approval |
| **Manager** | Everything a supervisor can, plus **approve / reject** inspection reports |
| **Admin** | Everything, plus **create users, reset passwords, change roles, disable/delete users** |

Roles are enforced **on the server** (not just hidden in the screen).

| | Local edition (one PC) | Web edition (Vercel) |
|---|---|---|
| Runs as | `node server.js` on the PC | Vercel serverless functions |
| Users / reports stored in | `C:\AutoBalloonData\db.json` (PC drive) | MongoDB (Atlas) |
| First admin | Created on first start in the browser | From `ADMIN_USERNAME` / `ADMIN_PASSWORD` env vars |
| Needs internet | No | Yes |

> **Where drawings and plans are kept:** in the browser of whoever uses the app (IndexedDB), on both editions. The server holds the **user accounts and the inspection reports submitted for approval**. Plans are therefore per browser/PC; reports become shared once submitted. (Moving plans and PDFs onto the server is a possible next step.)

---

## A. Local edition (one PC)

1. Install **Node.js LTS** (https://nodejs.org) – version 18 or newer. Nothing else to install (`npm install` is *not* needed).
2. Copy this folder to the PC, e.g. `C:\AutoBalloon`.
3. Double-click **`start-windows.bat`** (or run `node server.js`). The browser opens at http://localhost:3000.
4. First time only: you see **First-time setup**. Create the administrator name, username and password.
5. Go to **Users** and add your Managers and Quality Supervisors. They sign in with the temporary password you give and must choose their own.

* Data folder: `C:\AutoBalloonData` (change with the `DATA_DIR` environment variable). It holds `db.json` (users and reports), `db.json.bak` (previous copy) and `secret.key`. **Back this folder up.**
* By default only this PC can open the app (`127.0.0.1`). To let other PCs on your office network use it, start with `HOST=0.0.0.0` (Windows: `set HOST=0.0.0.0` then `node server.js`) and open `http://<this-pc-ip>:3000`. Use only on a trusted network (it is plain HTTP).
* Forgot the admin password: stop the server, delete `C:\AutoBalloonData\db.json` **only if you accept losing users and reports**, or ask another admin to reset your password.

## B. Web edition (Vercel + MongoDB Atlas)

1. **MongoDB Atlas** (free tier is enough): create a cluster → *Database Access*: add a database user → *Network Access*: allow `0.0.0.0/0` (Vercel uses changing IPs; the database is still protected by its user/password) → *Connect → Drivers*: copy the connection string (`MONGODB_URI`).
2. Put this folder in a **GitHub** repository (the `.gitignore` already keeps secrets out).
3. **Vercel** → *Add New Project* → import the repository. Framework preset: **Other**. No build command. Leave *Output Directory* empty (the `public/` folder is served automatically).
4. In *Settings → Environment Variables* add (see `.env.example`):
   `MONGODB_URI`, `MONGODB_DB`, `AUTH_SECRET` (32+ random characters), `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `ADMIN_NAME`.
5. Deploy. Open the site, sign in with `ADMIN_USERNAME` / `ADMIN_PASSWORD` (you must change the password at first sign-in), then add users from **Users**.
6. After the first sign-in you can remove `ADMIN_PASSWORD` from Vercel; it is only used while the database has no users.

Always use the `https://` address. Cookies are `HttpOnly`, `SameSite=Lax` and `Secure` on HTTPS.

## Security notes
* Passwords are hashed with scrypt (never stored in plain text); sessions are signed, expire after 12 hours, and end immediately when a password is reset or a user is disabled.
* 8 wrong passwords lock that account for 5 minutes.
* Cross-site requests are rejected (custom header + SameSite cookie).
* Use strong admin passwords, keep `AUTH_SECRET` private, and use HTTPS for anything that is not on `localhost`.

## Developer notes
* `lib/app.js` – the API (one handler used by both editions). `lib/store_file.js` – local storage. `lib/store_mongo.js` – MongoDB storage. `public/index.html` – the whole front end (generated).
* `npm test` runs the API tests (roles, lockout, approvals) for both storage back-ends.

## What is stored where (v2)

- **Plans, balloons, settings and the drawing PDFs are stored on the server, per account** – sign in from any browser or PC and the same plans are there. MongoDB collections: `plans`, `files` (PDF in 2 MB pieces, so Vercel's request limit is never hit), `cfg`, `users`, `reports`. Local edition: `db.json` plus a `files` folder inside `C:\AutoBalloonData`.
- A user sees **their own plans**; the **admin sees all** plans.
- **Send for approval** asks which manager(s) to send to. Only those managers (and the admin and the submitter) can see or decide that report; other managers never see it.
- Plans created in v1 are only in the browser that made them (not on the server). Open them there, duplicate is not needed – re-create or re-upload the drawing once in v2.
