'use strict';
/* Local server: run `node server.js` (or start-windows.bat). Data lives on this PC (default C:\AutoBalloonData). */
const http = require('http'), fs = require('fs'), path = require('path');
const store = require('./lib/store_file')();
const handle = require('./lib/app')({ store, secret: store.secret(), allowSetup: true });
const PORT = +process.env.PORT || 3000, HOST = process.env.HOST || '127.0.0.1';
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
const PUB = path.join(__dirname, 'public');
const server = http.createServer((req, res) => {
  if (req.url.startsWith('/api')) return handle(req, res);
  let p = decodeURIComponent(req.url.split('?')[0]); if (p === '/') p = '/index.html';
  const f = path.normalize(path.join(PUB, p)); if (!f.startsWith(PUB)) { res.writeHead(403); return res.end(); }
  fs.readFile(f, (err, buf) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin' }); res.end(buf);
  });
});
server.listen(PORT, HOST, () => {
  console.log(`\n  AutoBalloon is running:  http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`);
  console.log(`  Data folder:             ${store.dir}\n  Press Ctrl+C to stop.\n`);
  if (HOST === '0.0.0.0') console.log('  NOTE: reachable from other computers on your network. Use only on a trusted network.\n');
});
