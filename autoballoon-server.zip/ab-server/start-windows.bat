@echo off
title AutoBalloon
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Download the LTS version from https://nodejs.org and run this file again.
  pause
  exit /b 1
)
rem Data is stored in C:\AutoBalloonData (change with:  set DATA_DIR=D:\MyFolder)
start "" http://localhost:3000
node server.js
pause
