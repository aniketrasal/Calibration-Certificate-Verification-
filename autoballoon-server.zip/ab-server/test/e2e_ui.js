const { chromium } = require('playwright'); const { spawn } = require('child_process'); const fs = require('fs'), os = require('os'), path = require('path');
const PDF = process.env.PDF; let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'abui-')), port = 3900 + Math.floor(Math.random() * 90);
  const srv = spawn('node', ['server.js'], { cwd: path.join(__dirname, '..'), env: Object.assign({}, process.env, { PORT: port, DATA_DIR: dir }) });
  await new Promise(r => srv.stdout.on('data', d => String(d).includes('running') && r()));
  const base = 'http://127.0.0.1:' + port, br = await chromium.launch();
  const page = async () => { const ctx = await br.newContext({ viewport: { width: 1400, height: 900 } }); const pg = await ctx.newPage(); pg.on('pageerror', e => { console.log('PAGEERR', e.message); fails++; }); await pg.goto(base); return pg; };
  const login = async (pg, u, p) => { await pg.waitForSelector('#lgUser'); await pg.fill('#lgUser', u); await pg.fill('#lgPass', p); await pg.click('#lgGo'); };
  // 1. first run → setup
  let pg = await page(); await pg.waitForSelector('#lgName'); ok((await pg.textContent('.lock')).includes('First-time setup'), 'first run shows setup');
  await pg.fill('#lgName', 'Asha Admin'); await pg.fill('#lgUser', 'admin'); await pg.fill('#lgPass', 'admin-pass-1'); await pg.fill('#lgPass2', 'admin-pass-1'); await pg.click('#lgGo');
  await pg.waitForSelector('#newPlan, #emptyNew'); ok((await pg.textContent('.rolechip')).includes('Admin'), 'admin signed in after setup');
  ok(fs.existsSync(path.join(dir, 'db.json')), 'data written to the data folder');
  // 2. admin creates users
  await pg.click('#navUsers'); await pg.waitForSelector('#nuForm');
  for (const [n, u, r] of [['Sunita S', 'sunita', 'supervisor'], ['Manoj M', 'manoj', 'manager']]) { await pg.fill('#nuName', n); await pg.fill('#nuUser', u); await pg.selectOption('#nuRole', r); await pg.fill('#nuPass', 'temp-' + u + '-1'); await pg.click('#nuForm button'); await pg.waitForSelector(`#uB tr:has-text("${u}")`); }
  ok((await pg.locator('#uB tr').count()) === 3, 'users listed (3)');
  await pg.fill('#nuName', 'X'); await pg.fill('#nuUser', 'sunita'); await pg.fill('#nuPass', 'temp-x-123'); await pg.click('#nuForm button'); await pg.waitForFunction(() => document.querySelector('#nuErr').textContent.length > 0);
  ok((await pg.textContent('#nuErr')).includes('already taken'), 'duplicate username shows an error');
  // sign out via avatar menu
  await pg.click('.avatar'); await pg.click('.menu button:has-text("Sign out")'); await pg.waitForSelector('#lgUser'); ok(true, 'sign out returns to login');
  await login(pg, 'admin', 'wrong-pass'); await pg.waitForFunction(() => document.querySelector('#lgErr').textContent.length > 0); ok((await pg.textContent('#lgErr')).includes('Wrong username'), 'wrong password shows an error');
  await pg.context().close();
  // 3. supervisor: forced password change, works, submits
  pg = await page(); await login(pg, 'sunita', 'temp-sunita-1'); await pg.waitForSelector('#pwC'); ok(true, 'supervisor is forced to change the temporary password');
  await pg.fill('#pwC', 'temp-sunita-1'); await pg.fill('#pwN', 'sunita-own-pass'); await pg.fill('#pwN2', 'sunita-own-pass'); await pg.click('#pwOk'); await pg.waitForSelector('#newPlan, #emptyNew');
  ok((await pg.textContent('.rolechip')).includes('Quality Supervisor'), 'role chip: Quality Supervisor'); ok(!(await pg.isVisible('#navUsers')), 'no Users menu for supervisor');
  await pg.click('#newPlan, #emptyNew'); await pg.waitForSelector('#npFile', { state: 'attached' }); await pg.setInputFiles('#npFile', PDF); await pg.fill('#npPart', 'T-1');
  await pg.waitForFunction(() => !document.querySelector('#npCreate').disabled); await pg.click('#npCreate'); await pg.waitForSelector('#tAB'); await pg.waitForTimeout(600); await pg.click('#tAB');
  await pg.waitForSelector('#abGo'); await pg.click('#abGo'); await pg.waitForSelector('#ok', { timeout: 120000 }); await pg.click('#ok'); await pg.waitForTimeout(300);
  await pg.evaluate(() => window.__autoballoon.go('report', window.__autoballoon.S.plans[0].id)); await pg.waitForSelector('#aprGo'); await pg.click('#aprGo'); await pg.waitForTimeout(300);
  const c = await pg.$('.modal [data-a=y]'); if (c) await c.click(); await pg.waitForFunction(() => document.querySelector('#apr')?.textContent.includes('Pending approval'), null, { timeout: 15000 }); ok(true, 'report submitted, shows Pending approval');
  await pg.context().close();
  // 4. manager approves
  pg = await page(); await login(pg, 'manoj', 'temp-manoj-1'); await pg.waitForSelector('#pwC'); await pg.fill('#pwC', 'temp-manoj-1'); await pg.fill('#pwN', 'manoj-own-pass'); await pg.fill('#pwN2', 'manoj-own-pass'); await pg.click('#pwOk'); await pg.waitForSelector('#newPlan, #emptyNew');
  await pg.waitForFunction(() => document.querySelector('#navApprovals .lbl').textContent.includes('(1)'), null, { timeout: 15000 }); ok(true, 'manager sees 1 pending approval');
  await pg.click('#navApprovals'); await pg.waitForSelector('#aB tr'); await pg.click('#aB tr'); await pg.waitForSelector('#vA'); ok((await pg.locator('.modal tbody tr').count()) > 0, 'manager opens the full report rows');
  await pg.fill('#dNote', 'Approved for dispatch'); await pg.click('#vA'); await pg.waitForFunction(() => document.querySelector('#aB').textContent.includes('Approved'), null, { timeout: 15000 }); ok(true, 'manager approves');
  await pg.context().close();
  // 5. supervisor sees approved; data survives server restart
  pg = await page(); await login(pg, 'sunita', 'sunita-own-pass'); await pg.waitForSelector('#navApprovals'); await pg.click('#navApprovals'); await pg.waitForSelector('#aB tr'); ok((await pg.textContent('#aB')).includes('Approved'), 'supervisor sees Approved');
  await br.close(); srv.kill(); console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
