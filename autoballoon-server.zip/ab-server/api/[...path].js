'use strict';
/* Vercel entry point: all /api/* requests. Storage = MongoDB. */
const createApp = require('../lib/app'), mongoStore = require('../lib/store_mongo');
let handler;
module.exports = (req, res) => {
  try {
    if (!handler) handler = createApp({ store: mongoStore(), secret: process.env.AUTH_SECRET, allowSetup: false,
      seed: { username: process.env.ADMIN_USERNAME, password: process.env.ADMIN_PASSWORD, name: process.env.ADMIN_NAME } });
    return handler(req, res);
  } catch (e) { console.error(e); res.statusCode = 500; res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ error: 'Server is not configured: ' + e.message })); }
};
